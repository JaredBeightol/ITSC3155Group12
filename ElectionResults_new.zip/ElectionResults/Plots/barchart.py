import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import plotly.graph_objs as go
from dash.dependencies import Input, Output

# Load CSV file from Datasets folder
df = pd.read_csv('../Datasets/president_county_candidate.csv')
df1 = pd.read_csv('../Datasets/president_state.csv')
app = dash.Dash()

# Line Chart
line_df = df1
line_df = line_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
data_linechart = [go.Scatter(x=line_df['state'], y=line_df['total_votes'], mode='lines', name='votes')]

app.layout = html.Div(children=[
    html.H1(children='Election results',
            style={
                'textAlign': 'center',
                'color': '#ef3e18'
            }
            ),
    html.Div('Web dashboard for Data Visualization using Python', style={'textAlign': 'center'}),
    html.Div('Election results in 2020', style={'textAlign': 'center'}),
    html.Br(),
    html.Br(),
    html.Hr(style={'color': '#7FDBFF'}),
    # html.H3('Interactive Bar chart', style={'color': '#df1e56'}),
    html.Div('This bar chart represent the number of election votes in United State of selected party.'),
    dcc.Graph(id='graph1'),
    html.Div('Please select a party', style={'color': '#ef3e18', 'margin': '10px'}),
    dcc.Dropdown(
        id='select-party',
        options=[
            {'label': 'Democrat', 'value': 'DEM'},
            {'label': 'Republican', 'value': 'REP'},
            {'label': 'Green', 'value': 'GRN'},
            {'label': 'Libertarian', 'value': 'LIB'},

        ],
        value='DEM'
    ),
    html.Hr(style={'color': '#7FDBFF'}),
    html.H3('Line chart', style={'color': '#df1e56'}),
    html.Div('This line chart represent the total votes in United States.'),
    dcc.Graph(id='graph4',
              figure={
                  'data': data_linechart,
                  'layout': go.Layout(title='Total Votes in United States',
                                      xaxis={'title': 'State'}, yaxis={'title': 'Votes'})
              }
              )

])


@app.callback(Output('graph1', 'figure'),
              [Input('select-party', 'value')])
def update_figure(selected_party):
    filtered_df = df[df['party'] == selected_party]

    filtered_df = filtered_df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)
    new_df = filtered_df.groupby(['state'])['total_votes'].sum().reset_index()
    new_df = new_df.sort_values(by=['total_votes'], ascending=[False])
    data_interactive_barchart = [go.Bar(x=new_df['state'], y=new_df['total_votes'])]
    return {'data': data_interactive_barchart, 'layout': go.Layout(title='Number of votes in ' + selected_party,
                                                                   xaxis={'title': 'State'},
                                                                   yaxis={'title': 'Number of votes'})}


if __name__ == '__main__':
    app.run_server()
